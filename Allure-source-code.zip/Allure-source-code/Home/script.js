function goToHome(){
    window.location.href = "index.html";
}

function goToGallery(){
    window.location.href = "Gallery/galleryPage.html";
}

function goToCalendar(){
    window.location.href = "Calendar/calendarPage.html";
}

function goToProfile(){
    window.location.href = "Profile/profilePage.html";
}

function goToUpload(){
    window.location.href = "Upload/uploadPage.html";
}

function goToAI(){
    window.location.href = "AI/askAIpage.html";
}